<?php
//get data from form  

$name = $_POST['name'];
$email= $_POST['email'];
$number= $_POST['Phone_number'];
$adult= $_POST['total_adults'];
$children= $_POST['total_children'];
$checkin= $_POST['checkin'];
$checkout= $_POST['checkout'];
$Room = $_POST['Room'];
$message= $_POST['visitor_message'];


$to = "abdulramansagir@gmail.com";
$subject = "Mail From website";
$txt ="Name = ". $name . "\r\n  Email = " . $email . "\r\n Number =" . $Number . "\r\n Adult =" . $Aults
. "\r\n child =" . $children. "\r\n checkin =" . $checkin. "\r\n checkout =" . $checkout. "\r\n Room =" . $Room
. "\r\n  message =" . $message;
$headers = "From: noreply@yoursite.com" . "\r\n" .
"CC: somebodyelse@example.com";
if($email!=NULL){
    mail($to,$subject,$txt,$headers);
}
//redirect
header("Location:thankyou.html");
?>