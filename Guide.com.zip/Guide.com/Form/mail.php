<?php
//get data from form  

$name = $_POST['name'];
$email= $_POST['email'];

$number= $_POST['Phone_number'];
$batch= $_POST['batch'];
$country= $_POST['country'];
$Aboutus= $_POST['Aboutus'];
$message= $_POST['visitor_message'];


$to = "abdulramansagir@gmail.com";
$subject = "Mail From website";
$txt ="Name = ". $name . "\r\n  Email = " . $email . "\r\n Number =" . $Number . 
"\r\n batch =" . $batch . "\r\n  Aboutus =" . $Aboutus . "\r\n  message =" . $message;
$headers = "From: noreply@yoursite.com" . "\r\n" .
"CC: somebodyelse@example.com";
if($email!=NULL){
    mail($to,$subject,$txt,$headers);
}
//redirect
header("Location:thankyou.html");
?>